# La Troquita Tex Mex — Website

Three-page static site: `index.html` (Home), `menu.html` (Menu/"Services"), `contact.html` (Contact).
No build step — upload the folder to any host (Netlify, Cloudflare Pages, GitHub Pages, Hostinger, etc.).

## Before going live
1. **Photos** – put real photos in `images/` with these names (labeled placeholders show until you do):
   `hero.jpg`, `tacos.jpg`, `tacos-2.jpg`, `quesabirria.jpg`, `ceviche.jpg`, `truck.jpg`
   (Use the owner's own photos, or ones you take — don't copy Google Maps photos without permission.)
2. **Email** – replace `hello@latroquitatexmex.com` in `contact.html` with the real address.
3. **Contact form** – create a free form at formspree.io and replace `YOUR_FORM_ID` in `contact.html`.
4. **Menu** – confirm items with the owner and add prices if they want them shown.
5. **Domain** – e.g. latroquitatexmex.com; point it at your host.

Details pulled from their Google listing (Oct 2026): 1251 Taylor Ln, Lehigh Acres, FL 33936 · (239) 264-9853 ·
Wed–Thu 1–9, Fri 1–10, Sat 2–10, Sun 3–9, Mon–Tue closed.

## Maintenance checklist (monthly)
- Update hours/holiday closures and menu changes
- Swap in new photos
- Test the contact form and phone link
- Renew domain/hosting yearly

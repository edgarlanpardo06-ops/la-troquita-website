// Mobile menu
const toggle = document.querySelector('.menu-toggle');
const links = document.querySelector('.nav-links');
if (toggle && links) {
  toggle.addEventListener('click', () => {
    const open = links.classList.toggle('open');
    toggle.setAttribute('aria-expanded', open);
    toggle.textContent = open ? 'Close' : 'Menu';
  });
}

// Photo slots: show a labeled placeholder until real photos are added to /images
document.querySelectorAll('.photo img').forEach(img => {
  const mark = () => { img.style.display = 'none'; img.parentElement.classList.add('missing'); };
  if (img.complete && img.naturalWidth === 0) mark();
  img.addEventListener('error', mark);
});
document.querySelectorAll('.hero-bg img').forEach(img => {
  if (img.complete && img.naturalWidth === 0) img.remove();
  else img.addEventListener('error', () => img.remove());
});

// Highlight today's hours
const today = new Date().getDay(); // 0 = Sunday
document.querySelectorAll('.hours tr[data-day]').forEach(tr => {
  if (Number(tr.dataset.day) === today) tr.classList.add('today');
});

// Contact form (works with Formspree or any form endpoint set in the form's action)
const form = document.querySelector('form.contact');
if (form) {
  const status = form.querySelector('.form-status');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    status.className = 'form-status';
    status.textContent = 'Sending…';
    try {
      const res = await fetch(form.action, {
        method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' }
      });
      if (!res.ok) throw new Error();
      form.reset();
      status.classList.add('ok');
      status.textContent = '¡Gracias! We got your message and will get back to you soon.';
    } catch {
      status.classList.add('err');
      status.textContent = 'Something went wrong. Please call us at (239) 264-9853.';
    }
  });
}

document.querySelectorAll('.year').forEach(el => el.textContent = new Date().getFullYear());
